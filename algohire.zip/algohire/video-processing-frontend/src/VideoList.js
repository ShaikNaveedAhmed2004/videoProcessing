import React, { useEffect, useState } from "react";

function VideoList() {
    const [videos, setVideos] = useState([]);

    const fetchVideos = async () => {
        try {
            const res = await fetch("http://localhost:5000/videos");
            const data = await res.json();
            setVideos(data);
        } catch (err) {
            console.error("Failed to fetch videos", err);
        }
    };

    useEffect(() => {
        fetchVideos(); // initial load
        const interval = setInterval(fetchVideos, 3000); // poll every 3s
        return () => clearInterval(interval);
    }, []);

    if (videos.length === 0) {
        return <p>No videos uploaded yet.</p>;
    }

    return (
        <div>
            <h3>Uploaded Videos</h3>

            {videos.map((item) => (
                <div
                    key={item.video.id}
                    style={{
                        border: "1px solid #ccc",
                        padding: "10px",
                        marginBottom: "10px",
                    }}
                >
                    <strong>{item.video.original_filename}</strong>

                    <ul>
                        {item.tasks.map((task) => (
                            <li key={task.id}>
                                {task.format} / {task.profile} —{" "}
                                <strong>{task.state}</strong>

                                {task.state === "COMPLETED" && (
                                    <>
                                        {" "}
                                        |{" "}
                                        <a
                                            href={`http://localhost:5000/tasks/${task.id}/download`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                        >
                                            Download
                                        </a>
                                    </>
                                )}
                            </li>
                        ))}
                    </ul>
                </div>
            ))}
        </div>
    );
}

export default VideoList;
