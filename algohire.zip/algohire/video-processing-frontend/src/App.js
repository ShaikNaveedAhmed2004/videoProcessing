import React from "react";
import UploadForm from "./UploadForm";
import VideoList from "./VideoList";

function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Async Video Processing System</h1>
      <UploadForm />
      <hr />
      <VideoList />
    </div>
  );
}

export default App;
