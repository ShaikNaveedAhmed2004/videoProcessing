import React, { useState } from "react";

function UploadForm() {
    const [video, setVideo] = useState(null);
    const [variants, setVariants] = useState({
        mp4_p1: false,
        webm_p2: false,
    });

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!video) {
            alert("Please select a video");
            return;
        }

        const selectedVariants = [];
        if (variants.mp4_p1)
            selectedVariants.push({ format: "MP4", profile: "P1" });
        if (variants.webm_p2)
            selectedVariants.push({ format: "WebM", profile: "P2" });

        if (selectedVariants.length === 0) {
            alert("Select at least one output variant");
            return;
        }

        const formData = new FormData();
        formData.append("video", video);
        formData.append("variants", JSON.stringify(selectedVariants));

        await fetch("http://localhost:5000/videos", {
            method: "POST",
            body: formData,
        });

        alert("Video uploaded and tasks created");
        setVideo(null);
    };

    return (
        <form onSubmit={handleSubmit}>
            <h3>Upload Video</h3>

            <input
                type="file"
                accept="video/*"
                onChange={(e) => setVideo(e.target.files[0])}
            />

            <div>
                <label>
                    <input
                        type="checkbox"
                        checked={variants.mp4_p1}
                        onChange={(e) =>
                            setVariants({ ...variants, mp4_p1: e.target.checked })
                        }
                    />
                    MP4 (P1 – 480p)
                </label>
            </div>

            <div>
                <label>
                    <input
                        type="checkbox"
                        checked={variants.webm_p2}
                        onChange={(e) =>
                            setVariants({ ...variants, webm_p2: e.target.checked })
                        }
                    />
                    WebM (P2 – 720p)
                </label>
            </div>

            <button type="submit">Upload</button>
        </form>
    );
}

export default UploadForm;
