const { Pool } = require("pg");

const pool = new Pool({
    host: "localhost",
    user: "postgres",
    password: "Naveed@2004",
    database: "video_db",
    port: 5432,
});

module.exports = pool;
