const pool = require("./db");
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
const path = require("path");

console.log("Background worker started...");

async function processNextTask() {
    try {

        const result = await pool.query(
            `SELECT * FROM tasks
       WHERE state = 'QUEUED'
       ORDER BY created_at
       LIMIT 1`
        );

        if (result.rows.length === 0) {
            return;
        }

        const task = result.rows[0];

        console.log(`Processing task ${task.id}`);


        await pool.query(
            `UPDATE tasks
       SET state = 'PROCESSING', started_at = NOW()
       WHERE id = $1`,
            [task.id]
        );


        await new Promise((resolve) => setTimeout(resolve, 5000));


        const outputFile = `${uuidv4()}_${task.format}_${task.profile}.txt`;
        const outputPath = path.join("outputs", outputFile);

        fs.writeFileSync(
            outputPath,
            `Processed video for task ${task.id}`
        );


        await pool.query(
            `UPDATE tasks
       SET state = 'COMPLETED',
           output_path = $1,
           completed_at = NOW()
       WHERE id = $2`,
            [outputPath, task.id]
        );

        console.log(`Task ${task.id} completed`);
    } catch (err) {
        console.error("Worker error:", err.message);
    }
}

setInterval(processNextTask, 3000);
