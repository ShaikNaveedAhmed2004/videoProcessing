const cors = require("cors");
const express = require("express");
const multer = require("multer");
const path = require("path");
const { v4: uuidv4 } = require("uuid");
const pool = require("./db");

const app = express();
app.use(express.json());
app.use(cors());
const fs = require("fs");

if (!fs.existsSync("uploads")) fs.mkdirSync("uploads");
if (!fs.existsSync("outputs")) fs.mkdirSync("outputs");


const storage = multer.diskStorage({
    destination: "uploads/",
    filename: (req, file, cb) => {
        const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
        cb(null, uniqueName);
    },
});

const upload = multer({
    storage,
    limits: { fileSize: 200 * 1024 * 1024 }, // 200 MB
    fileFilter: (req, file, cb) => {
        const allowed = ["video/mp4", "video/quicktime", "video/webm"];
        if (allowed.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error("Unsupported file format"));
        }
    },
});


app.get("/", (req, res) => {
    res.json({ status: "Backend running" });
});

app.post("/videos", upload.single("video"), async (req, res) => {
    try {
        const { variants } = req.body;
        const videoId = uuidv4();
        const filePath = req.file.path;


        await pool.query(
            "INSERT INTO videos (id, original_filename, file_path) VALUES ($1, $2, $3)",
            [videoId, req.file.originalname, filePath]
        );

        const parsedVariants = JSON.parse(variants);
        const taskIds = [];

        for (const v of parsedVariants) {
            const taskId = uuidv4();
            taskIds.push(taskId);

            await pool.query(
                `INSERT INTO tasks (id, video_id, format, profile, state)
         VALUES ($1, $2, $3, $4, 'QUEUED')`,
                [taskId, videoId, v.format, v.profile]
            );
        }

        res.status(201).json({
            message: "Video uploaded. Tasks created.",
            videoId,
            tasks: taskIds,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// Get all videos with their tasks
app.get("/videos", async (req, res) => {
    try {
        const videosResult = await pool.query(
            "SELECT * FROM videos ORDER BY created_at DESC"
        );

        const videos = [];

        for (const video of videosResult.rows) {
            const tasksResult = await pool.query(
                "SELECT * FROM tasks WHERE video_id = $1 ORDER BY created_at",
                [video.id]
            );

            videos.push({
                video,
                tasks: tasksResult.rows,
            });
        }

        res.json(videos);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Download completed task output
app.get("/tasks/:id/download", async (req, res) => {
    try {
        const { id } = req.params;

        const result = await pool.query(
            "SELECT * FROM tasks WHERE id = $1",
            [id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: "Task not found" });
        }

        const task = result.rows[0];

        if (task.state !== "COMPLETED") {
            return res.status(400).json({ error: "Task not completed yet" });
        }

        res.download(task.output_path);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});



const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
